
'use strict';

var canvas = document.createElement('canvas');
canvas.width = Math.min(window.innerWidth, window.innerHeight);
canvas.height = canvas.width;
document.body.appendChild(canvas);

var gl = canvas.getContext( 'webgl', { antialias: false } );

// -- Init program
var boxShading = new ShaderProgram(gl, 'vs', 'fs',0);
var particleShading = new ShaderProgram(gl, 'vs', 'fs',1);

// -- Init objects
var box = new Box(gl);
box.create(gl);

var fluid = new Fluid();
fluid.init(gl,box.faces);

// var particle = new Particle(gl,1.0,2.0,3.0);
// particle.create(gl);


// -- Init camera
var camera = new Camera();

// -- UI control
var drag_flag= -1;
var cam_transform= mat4.create();
var rotX= 0.0;
var rotY= 0.0;
var calibX= 0.0;
var calibY= 0.0;




var requestAnimationFrame =
window.requestAnimationFrame ||
window.webkitRequestAnimationFrame ||
function(callback) { setTimeout(callback, 0); };




render();

var time_count= 0;

function render() {
    // -- Render
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);
    
    var drawmat= mat4.create();
    drawmat= mat4.rotateX(cam_transform, mat4.rotateY(cam_transform, camera.viewProj, rotX), rotY);
    
    boxShading.draw(gl, box,  drawmat);
    
    for(var i=0;i<fluid.emit_size;i++){
        fluid.solver(i,gl,time_count);
        particleShading.draw(gl, fluid.particles[i],  drawmat);
    }

    time_count+=1;

    requestAnimationFrame(render);
}

function cleanup() {
    // Delete WebGL resources
    gl.deleteBuffer(vertexBuffer);
    gl.deleteBuffer(indexBuffer);
    gl.deleteProgram(program);

}






//ui


function startDrag(x, y) {
    drag_flag=1;
    calibX=x/1000;
    calibY=y/1000;
}

function duringDrag(x, y) {
    if(drag_flag==1){
        rotX+= x/1000-calibX;
        rotY+= y/1000-calibY;
    }
}

function stopDrag() {
    drag_flag=-1;
    calibX=0;
    calibY=0;
}

document.onmousedown = function(e) {
    e.preventDefault();
    startDrag(e.pageX, e.pageY);
};

document.onmousemove = function(e) {
    duringDrag(e.pageX, e.pageY);
};

document.onmouseup = function() {
    stopDrag();
};
