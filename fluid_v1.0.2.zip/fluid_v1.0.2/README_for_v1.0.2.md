include previous readme

- compatability problem of particle appearance solved