
how to use:
-open main.html in your browser.
-use decent browsers which supports javascript, like chrome or firefox
-camera control: use your mouse to drag, currently I don't allow zooming

not implemented:
-loading scene json file; will do if I have time before wed

extra features:
-no

-code structures:
main entrance is html, webgl contents initiate in canvas; main functions are in js folder;



fluid system includes matrix information of geometry
shader.js is the final shading program draw things out
camera.js is the matrix of view point
ui, integration and render in render.js: they are in the same file because I need to jump around to fix things in that file when coding.

gl and other important things are initiated in render.js; once geometries are buffered and binded, passed to render function (a self calling function). UI are written at the bottom of render.js


Note:
-did not change the color of particles; have some issue with webgl color buffer; but I made particles collide, which is an equivalent strong proof that I detect collision.


the base code is a rewrite version of Adam Mally's webgl basic view homework to 277 students; rewrite task is done by Trung Le.

the current works you see here underwent a structural change by Kuan Wang of course.
no external works except things in 3rd party folders.
and this work is not allowed to be cited in any case at this point. Please don't share as well.


-cheers
Kuan Wang